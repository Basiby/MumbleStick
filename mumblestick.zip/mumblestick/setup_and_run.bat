@echo off
title Mumble Stick - Setup & Launch
echo ==========================================
echo    MUMBLE STICK - INSTALLATION & START
echo ==========================================
echo.

:: Check for Python installation
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed! Please install it from python.org.
    pause
    exit
)

echo [1/2] Installing required libraries (Pillow, pyautogui)...
pip install Pillow pyautogui --quiet

if %errorlevel% neq 0 (
    echo [ERROR] Failed to install libraries. Check your internet connection.
    pause
    exit
)

echo [OK] Libraries are ready.
echo.
echo [2/2] Launching Mumble Stick...
:: Make sure your python file is named mumble_stick.py
python mumble_stick.py

echo.
echo Program has been closed.
pause
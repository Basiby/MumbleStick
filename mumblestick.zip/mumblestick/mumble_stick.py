import tkinter as tk
from PIL import Image, ImageTk  # POTREBUJEŠ: pip install Pillow
import random
import pyautogui
import os

class RapperStickman:
    def __init__(self):
        self.root = tk.Tk()
        self.sw, self.sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        self.root.overrideredirect(True)
        self.root.wm_attributes('-transparentcolor', 'black', '-topmost', True)

        self.win_size = 150
        self.canvas = tk.Canvas(self.root, width=self.win_size, height=self.win_size, bg='black', highlightthickness=0)
        self.canvas.pack()

        # NAČÍTANIE A ZMENŠENIE HLAVY
        self.head_img = None
        head_path = os.path.join(os.path.dirname(__file__), "head.png")
        if os.path.exists(head_path):
            try:
                img = Image.open(head_path).convert("RGBA")
                img.thumbnail((50, 50), Image.Resampling.LANCZOS) # Automatický resize!
                self.head_img = ImageTk.PhotoImage(img)
            except Exception as e:
                print(f"Chyba hlavy: {e}")

        self.x, self.ground_y = random.randint(100, self.sw - 100), self.sh - 160 
        self.y = self.ground_y
        self.state, self.dir, self.timer, self.fall_speed, self.frame_count = "walking", 1, 0, 0, 0

        self.canvas.bind("<ButtonPress-1>", self.start_drag)
        self.canvas.bind("<B1-Motion>", self.drag)
        self.canvas.bind("<ButtonRelease-1>", self.stop_drag)

        self.update()
        self.root.mainloop()

    def draw(self, offset=0):
        self.canvas.delete("all")
        c, mx = "white", self.win_size // 2 
        
        if self.timer > 0: self.timer -= 1
        elif self.state in ["waving", "dizzy", "sitting", "jumping", "pranking"]: self.state = "walking"

        hy = 65
        if self.state == "sitting": hy = 85 
        elif self.state == "dizzy": hy = 110
        elif self.state == "jumping": hy = 40
        
        if self.state != "dizzy":
            # HLAVA
            if self.head_img: self.canvas.create_image(mx, hy-20, image=self.head_img)
            else: self.canvas.create_oval(mx-12, hy-25, mx+12, hy, outline=c, width=2)
            
            # TELO
            self.canvas.create_line(mx, hy, mx, hy+30, fill=c, width=2)
            ty, by = hy + 10, hy + 30 

            # KONČATINY PODĽA STAVU
            if self.state in ["walking", "pranking", "dragging"]:
                self.canvas.create_line(mx, ty, mx-15+offset, ty+15, fill=c, width=2)
                self.canvas.create_line(mx, ty, mx+15-offset, ty+15, fill=c, width=2)
                self.canvas.create_line(mx, by, mx-10-offset, by+20, fill=c, width=2)
                self.canvas.create_line(mx, by, mx+10+offset, by+20, fill=c, width=2)
            
            elif self.state == "falling":
                self.canvas.create_line(mx, ty, mx-20, ty-10, fill=c, width=2) # Ruky hore
                self.canvas.create_line(mx, ty, mx+20, ty-10, fill=c, width=2)
                self.canvas.create_line(mx, by, mx-10, by+15, fill=c, width=2)
                self.canvas.create_line(mx, by, mx+10, by+15, fill=c, width=2)
                self.canvas.create_text(mx, hy-60, text="LOOK OUT!", fill="red")

            elif self.state == "jumping":
                # FIX: Animácia skoku
                self.canvas.create_line(mx, ty, mx-15, ty-15, fill=c, width=2)
                self.canvas.create_line(mx, ty, mx+15, ty-15, fill=c, width=2)
                self.canvas.create_line(mx, by, mx-15, by+5, fill=c, width=2) # Pokrčené nohy
                self.canvas.create_line(mx, by, mx+15, by+5, fill=c, width=2)

            elif self.state == "sitting":
                self.canvas.create_line(mx, ty, mx+15, ty+10, fill=c, width=2)
                self.canvas.create_line(mx, by, mx+20, by, fill=c, width=2)
                self.canvas.create_line(mx+20, by, mx+20, by+15, fill=c, width=2)
                self.canvas.create_text(mx, hy-60, text="STUDIO MODE", fill="cyan", font=("Arial", 8, "bold"))

        else: # DIZZY
            if self.head_img: self.canvas.create_image(mx+15, hy-10, image=self.head_img)
            self.canvas.create_line(mx, hy, mx+30, hy, fill=c, width=2)
            self.canvas.create_text(mx, hy-45, text="MUMBLE RAP...", fill="yellow")

    def start_drag(self, event): self.state = "dragging"
    def drag(self, event):
        self.x, self.y = self.root.winfo_pointerx() - 75, self.root.winfo_pointery() - 75
        self.root.geometry(f"150x150+{self.x}+{self.y}"); self.draw(); self.root.update()

    def stop_drag(self, event):
        self.state = "falling" if self.y < self.ground_y - 30 else "walking"

    def update(self):
        self.frame_count = (self.frame_count + 1) % 4
        offset = 5 if self.frame_count < 2 else 0
        if self.state == "walking":
            self.x += self.dir * 4
            if self.x > self.sw - 150 or self.x < 0: self.dir *= -1
            r = random.random()
            if r < 0.006: 
                pyautogui.press('space')
                self.state, self.timer = "pranking", 20
            elif r < 0.02: self.state, self.timer = "jumping", 20
            elif r < 0.03: self.state, self.timer = "sitting", 100
        elif self.state == "falling":
            self.fall_speed += 4
            self.y += self.fall_speed
            if self.y >= self.ground_y: self.y, self.state, self.timer, self.fall_speed = self.ground_y, "dizzy", 60, 0

        if self.state != "dragging":
            self.draw(offset)
            self.root.geometry(f"150x150+{int(self.x)}+{int(self.y)}")
        self.root.after(50, self.update)

if __name__ == "__main__":
    RapperStickman()